#include <iostream>
using namespace std;
int main() {
    std::cout << "El tipo de datos char se representa utilizando "
    << sizeof(char) << " bytes." << endl;
    std::cout << "El tipo de datos bool se representa utilizando "
    << sizeof(bool) << " bytes." << endl;
    std::cout << "El tipo de datos int se representa utilizando " 
    << sizeof(int) << " bytes." << endl;
    std::cout << "El tipo de datos float se representa utilizando "
    << sizeof(float) << " bytes." << endl;
    std::cout << "El tipo de datos double se representa utilizando "
    << sizeof(double) << " bytes." << endl;
    
    
}